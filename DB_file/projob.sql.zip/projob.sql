-- phpMyAdmin SQL Dump
-- version 4.9.0.1
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: Dec 10, 2019 at 10:59 AM
-- Server version: 10.3.16-MariaDB
-- PHP Version: 7.1.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `projob`
--

-- --------------------------------------------------------

--
-- Table structure for table `addresses`
--

CREATE TABLE `addresses` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `township_id` bigint(20) UNSIGNED NOT NULL,
  `street_id` bigint(20) UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `addresses`
--

INSERT INTO `addresses` (`id`, `township_id`, `street_id`, `created_at`, `updated_at`, `deleted_at`) VALUES
(1, 1, 1, '2019-11-25 03:04:31', '2019-11-25 03:04:31', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `companies`
--

CREATE TABLE `companies` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `company_overview` longtext COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `register_no` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `ea_no` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `company_size` longtext COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `industry` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `location` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `average_processtime` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `benefit_other` longtext COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `gallery` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `cover_photo` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `logo` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `type_id` bigint(20) UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `ea_register_no` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `companies`
--

INSERT INTO `companies` (`id`, `name`, `company_overview`, `register_no`, `ea_no`, `company_size`, `industry`, `location`, `average_processtime`, `benefit_other`, `gallery`, `cover_photo`, `logo`, `type_id`, `created_at`, `updated_at`, `deleted_at`, `ea_register_no`) VALUES
(1, 'Achieve Career Consultant Pte Ltd', '<p><span style=\"color: rgb(51, 51, 51); font-family: Muli, -apple-system, system-ui, &quot;Segoe UI&quot;, Roboto, &quot;Noto Sans&quot;, Ubuntu, &quot;Droid Sans&quot;, &quot;Helvetica Neue&quot;, Arial, sans-serif; text-align: justify;\">Founded in Singapore in 1990, Achieve Group is a multi award-winning organisation and HR outsourcing partner-of-choice for local conglomerates and multinational corporations within the Asia Pacific region.</span><br style=\"font-family: Muli, -apple-system, system-ui, &quot;Segoe UI&quot;, Roboto, &quot;Noto Sans&quot;, Ubuntu, &quot;Droid Sans&quot;, &quot;Helvetica Neue&quot;, Arial, sans-serif; box-sizing: inherit; -webkit-tap-highlight-color: transparent; color: rgb(51, 51, 51); text-align: justify;\"><br style=\"font-family: Muli, -apple-system, system-ui, &quot;Segoe UI&quot;, Roboto, &quot;Noto Sans&quot;, Ubuntu, &quot;Droid Sans&quot;, &quot;Helvetica Neue&quot;, Arial, sans-serif; box-sizing: inherit; -webkit-tap-highlight-color: transparent; color: rgb(51, 51, 51); text-align: justify;\"><span style=\"color: rgb(51, 51, 51); font-family: Muli, -apple-system, system-ui, &quot;Segoe UI&quot;, Roboto, &quot;Noto Sans&quot;, Ubuntu, &quot;Droid Sans&quot;, &quot;Helvetica Neue&quot;, Arial, sans-serif; text-align: justify;\">With offices in Singapore, Malaysia and Hong Kong, Achieve Group offers a full suite of Talent Acquisition and HR Consulting solutions for your company\'s HRM needs. As the experts in talent recruitment and human resource engagement services, we pride ourselves on the timely delivery of these services through our team of dedicated and experienced professionals.</span><br style=\"font-family: Muli, -apple-system, system-ui, &quot;Segoe UI&quot;, Roboto, &quot;Noto Sans&quot;, Ubuntu, &quot;Droid Sans&quot;, &quot;Helvetica Neue&quot;, Arial, sans-serif; box-sizing: inherit; -webkit-tap-highlight-color: transparent; color: rgb(51, 51, 51); text-align: justify;\"><br style=\"font-family: Muli, -apple-system, system-ui, &quot;Segoe UI&quot;, Roboto, &quot;Noto Sans&quot;, Ubuntu, &quot;Droid Sans&quot;, &quot;Helvetica Neue&quot;, Arial, sans-serif; box-sizing: inherit; -webkit-tap-highlight-color: transparent; color: rgb(51, 51, 51); text-align: justify;\"><span style=\"color: rgb(51, 51, 51); font-family: Muli, -apple-system, system-ui, &quot;Segoe UI&quot;, Roboto, &quot;Noto Sans&quot;, Ubuntu, &quot;Droid Sans&quot;, &quot;Helvetica Neue&quot;, Arial, sans-serif; text-align: justify;\">As a progressive organization that firmly believes in the pursuit of excellence, Achieve Group is always constantly evaluating and seeking to improve ourselves to fulfill our mission, because we believe that \'Your SUCCESS is our ACHIEVEment\'!</span><br></p>', '199801996Z', '05C3451', '51 - 200 Employees', 'Human Resources Management / Consulting', 'Singapore', NULL, NULL, '[[]]', NULL, '1575018406.jpg', 1, '2019-11-29 02:36:46', '2019-11-29 02:36:46', NULL, 'R1105012'),
(2, 'Testing ttm', '<p>testing overview</p>', '242424242', 'tqtqtq', '101-200 employees', NULL, NULL, NULL, NULL, '[null]', '1575273757.jpg', '1575273757.jpg', 1, '2019-12-02 01:32:37', '2019-12-10 00:33:34', NULL, 'afafafa5353'),
(3, 'Tun Min', '<p>testing overview tt</p>', '242424242', 'tqtqtq', '101-200 employees', NULL, 'Ygn', NULL, NULL, '[null]', '1575274034.jpg', NULL, 2, '2019-12-02 01:37:14', '2019-12-03 02:20:42', NULL, 'afafafa5353'),
(4, 'Tun Tun Min(4-12-19)', '<p>Tun Company Overveiw</p><p>If u more try, u will more get</p>', 'ttm333433', '353533', NULL, NULL, 'Yangon', NULL, NULL, '[\"cte-in-sql-server.jpg\"]', '1575432165.jpg', '1575430744.jpg', 1, '2019-12-02 02:30:57', '2019-12-04 21:21:32', NULL, NULL),
(5, 'ttm-testing', '<p>testing</p>', '12', 'aa', 'faf', 'afa', 'Mdy', NULL, NULL, '[\"add-class.png\",\"1575617791.jpg\",\"html.png\"]', '1575619757.jpg', NULL, 1, '2019-12-04 11:25:26', '2019-12-10 00:54:41', '2019-12-10 00:54:41', 'afaf');

-- --------------------------------------------------------

--
-- Table structure for table `jobs`
--

CREATE TABLE `jobs` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `title` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `post_date` datetime NOT NULL,
  `job_highlights` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `job_description` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `career_level` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `qualification` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `employee_type` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `salary_unit` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `salary_from` int(11) NOT NULL,
  `salary_to` int(11) NOT NULL,
  `job_specification_id` bigint(20) UNSIGNED NOT NULL,
  `job_type_id` bigint(20) UNSIGNED NOT NULL,
  `company_id` bigint(20) UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `jobs`
--

INSERT INTO `jobs` (`id`, `title`, `post_date`, `job_highlights`, `job_description`, `career_level`, `qualification`, `employee_type`, `salary_unit`, `salary_from`, `salary_to`, `job_specification_id`, `job_type_id`, `company_id`, `created_at`, `updated_at`, `deleted_at`) VALUES
(1, 'NodeJS Developer (Junior)', '2019-12-09 00:00:00', '<p>testing</p>', '<div style=\"margin: 0px; padding: 0px; border: 0px; font-variant-numeric: inherit; font-variant-east-asian: inherit; font-stretch: inherit; line-height: inherit; font-family: Muli, -apple-system, system-ui, &quot;Segoe UI&quot;, Roboto, &quot;Noto Sans&quot;, Ubuntu, &quot;Droid Sans&quot;, &quot;Helvetica Neue&quot;, Arial, sans-serif; vertical-align: baseline; box-sizing: inherit; -webkit-tap-highlight-color: transparent; color: rgb(51, 51, 51); text-align: justify;\"><span style=\"margin: 0px; padding: 0px; border: 0px; font-style: inherit; font-variant: inherit; font-weight: 700; font-stretch: inherit; font-size: inherit; line-height: inherit; font-family: inherit; vertical-align: baseline; box-sizing: inherit; -webkit-tap-highlight-color: transparent;\">The Company</span></div><div style=\"margin: 0px; padding: 0px; border: 0px; font-variant-numeric: inherit; font-variant-east-asian: inherit; font-stretch: inherit; line-height: inherit; font-family: Muli, -apple-system, system-ui, &quot;Segoe UI&quot;, Roboto, &quot;Noto Sans&quot;, Ubuntu, &quot;Droid Sans&quot;, &quot;Helvetica Neue&quot;, Arial, sans-serif; vertical-align: baseline; box-sizing: inherit; -webkit-tap-highlight-color: transparent; color: rgb(51, 51, 51); text-align: justify;\">Fugro is the world’s leading Geo-data specialist, collecting and analysing comprehensive information about the Earth and the structures built upon it. Through integrated data acquisition, analysis and advice, we unlock insights from Geo-data to help our clients design, build and operate their assets in a safe, sustainable and efficient manner.</div><div style=\"margin: 0px; padding: 0px; border: 0px; font-variant-numeric: inherit; font-variant-east-asian: inherit; font-stretch: inherit; line-height: inherit; font-family: Muli, -apple-system, system-ui, &quot;Segoe UI&quot;, Roboto, &quot;Noto Sans&quot;, Ubuntu, &quot;Droid Sans&quot;, &quot;Helvetica Neue&quot;, Arial, sans-serif; vertical-align: baseline; box-sizing: inherit; -webkit-tap-highlight-color: transparent; color: rgb(51, 51, 51); text-align: justify;\">&nbsp;</div><div style=\"margin: 0px; padding: 0px; border: 0px; font-variant-numeric: inherit; font-variant-east-asian: inherit; font-stretch: inherit; line-height: inherit; font-family: Muli, -apple-system, system-ui, &quot;Segoe UI&quot;, Roboto, &quot;Noto Sans&quot;, Ubuntu, &quot;Droid Sans&quot;, &quot;Helvetica Neue&quot;, Arial, sans-serif; vertical-align: baseline; box-sizing: inherit; -webkit-tap-highlight-color: transparent; color: rgb(51, 51, 51); text-align: justify;\">One of the ways we do this is by developing and manufacturing our in-house designed Remote Operated Vehicles (ROVs). This is done in the Fugro ROV production and support facility in Loyang, Singapore. The ROVs are being used by Fugro operational teams and external clients around the world. ROV systems are used to conduct inspection, repair, maintenance and support work for the offshore Oil&amp;Gas, infrastructure and renewables industries, in depths of up to 4000 meters of water. Building and designing ROVs require a combination of mechanical, electrical, electronics and software engineer disciplines, as well as a hands-on mindset to support the offshore teams in the delivery of bespoke projects.&nbsp;&nbsp;&nbsp;</div><div style=\"margin: 0px; padding: 0px; border: 0px; font-variant-numeric: inherit; font-variant-east-asian: inherit; font-stretch: inherit; line-height: inherit; font-family: Muli, -apple-system, system-ui, &quot;Segoe UI&quot;, Roboto, &quot;Noto Sans&quot;, Ubuntu, &quot;Droid Sans&quot;, &quot;Helvetica Neue&quot;, Arial, sans-serif; vertical-align: baseline; box-sizing: inherit; -webkit-tap-highlight-color: transparent; color: rgb(51, 51, 51); text-align: justify;\">&nbsp;</div><div style=\"margin: 0px; padding: 0px; border: 0px; font-variant-numeric: inherit; font-variant-east-asian: inherit; font-stretch: inherit; line-height: inherit; font-family: Muli, -apple-system, system-ui, &quot;Segoe UI&quot;, Roboto, &quot;Noto Sans&quot;, Ubuntu, &quot;Droid Sans&quot;, &quot;Helvetica Neue&quot;, Arial, sans-serif; vertical-align: baseline; box-sizing: inherit; -webkit-tap-highlight-color: transparent; color: rgb(51, 51, 51); text-align: justify;\"><span style=\"margin: 0px; padding: 0px; border: 0px; font-style: inherit; font-variant: inherit; font-weight: 700; font-stretch: inherit; font-size: inherit; line-height: inherit; font-family: inherit; vertical-align: baseline; box-sizing: inherit; -webkit-tap-highlight-color: transparent;\">Position Summary</span></div><div style=\"margin: 0px; padding: 0px; border: 0px; font-variant-numeric: inherit; font-variant-east-asian: inherit; font-stretch: inherit; line-height: inherit; font-family: Muli, -apple-system, system-ui, &quot;Segoe UI&quot;, Roboto, &quot;Noto Sans&quot;, Ubuntu, &quot;Droid Sans&quot;, &quot;Helvetica Neue&quot;, Arial, sans-serif; vertical-align: baseline; box-sizing: inherit; -webkit-tap-highlight-color: transparent; color: rgb(51, 51, 51); text-align: justify;\">Fugro is looking for a pro-active Quality Engineer to continually improve the quality of their deliverables. Due to the importance of the function the Quality Engineer will report directly to the Global ROV Production Manager. Day to day activities shall include the improvement of the quality management system, quality control of all incoming and outgoing products and working with the procurement team and supply chain to improve the quality of externally provided products and services.</div><div style=\"margin: 0px; padding: 0px; border: 0px; font-variant-numeric: inherit; font-variant-east-asian: inherit; font-stretch: inherit; line-height: inherit; font-family: Muli, -apple-system, system-ui, &quot;Segoe UI&quot;, Roboto, &quot;Noto Sans&quot;, Ubuntu, &quot;Droid Sans&quot;, &quot;Helvetica Neue&quot;, Arial, sans-serif; vertical-align: baseline; box-sizing: inherit; -webkit-tap-highlight-color: transparent; color: rgb(51, 51, 51); text-align: justify;\">&nbsp;</div><div style=\"margin: 0px; padding: 0px; border: 0px; font-variant-numeric: inherit; font-variant-east-asian: inherit; font-stretch: inherit; line-height: inherit; font-family: Muli, -apple-system, system-ui, &quot;Segoe UI&quot;, Roboto, &quot;Noto Sans&quot;, Ubuntu, &quot;Droid Sans&quot;, &quot;Helvetica Neue&quot;, Arial, sans-serif; vertical-align: baseline; box-sizing: inherit; -webkit-tap-highlight-color: transparent; color: rgb(51, 51, 51); text-align: justify;\"><span style=\"margin: 0px; padding: 0px; border: 0px; font-style: inherit; font-variant: inherit; font-weight: 700; font-stretch: inherit; font-size: inherit; line-height: inherit; font-family: inherit; vertical-align: baseline; box-sizing: inherit; -webkit-tap-highlight-color: transparent;\">Key Responsibilities</span></div><ul style=\"margin-right: 0px; margin-bottom: 0px; margin-left: 0px; padding: 0px 0px 12px; border: 0px; font-variant-numeric: inherit; font-variant-east-asian: inherit; font-stretch: inherit; line-height: inherit; font-family: Muli, -apple-system, system-ui, &quot;Segoe UI&quot;, Roboto, &quot;Noto Sans&quot;, Ubuntu, &quot;Droid Sans&quot;, &quot;Helvetica Neue&quot;, Arial, sans-serif; vertical-align: baseline; list-style: none; box-sizing: inherit; -webkit-tap-highlight-color: transparent; color: rgb(51, 51, 51); text-align: justify;\"><li style=\"margin: 0px 0px 0px 16px; padding: 0px 0px 4px; border: 0px; font: inherit; vertical-align: baseline; box-sizing: inherit; -webkit-tap-highlight-color: transparent; list-style: outside disc;\"><div style=\"margin: 0px; padding: 0px; border: 0px; font: inherit; vertical-align: baseline; box-sizing: inherit; -webkit-tap-highlight-color: transparent;\">Liaise with the ROV Production Manager and Global Quality Manager in relation to continuous improvement of the quality management system.</div></li><li style=\"margin: 0px 0px 0px 16px; padding: 0px 0px 4px; border: 0px; font: inherit; vertical-align: baseline; box-sizing: inherit; -webkit-tap-highlight-color: transparent; list-style: outside disc;\"><div style=\"margin: 0px; padding: 0px; border: 0px; font: inherit; vertical-align: baseline; box-sizing: inherit; -webkit-tap-highlight-color: transparent;\">Translate quality findings into design improvement suggestions to the engineering design teams.</div></li><li style=\"margin: 0px 0px 0px 16px; padding: 0px 0px 4px; border: 0px; font: inherit; vertical-align: baseline; box-sizing: inherit; -webkit-tap-highlight-color: transparent; list-style: outside disc;\"><div style=\"margin: 0px; padding: 0px; border: 0px; font: inherit; vertical-align: baseline; box-sizing: inherit; -webkit-tap-highlight-color: transparent;\">Assure quality of mechanical, hydraulic and hydrostatic testing.</div></li><li style=\"margin: 0px 0px 0px 16px; padding: 0px 0px 4px; border: 0px; font: inherit; vertical-align: baseline; box-sizing: inherit; -webkit-tap-highlight-color: transparent; list-style: outside disc;\"><div style=\"margin: 0px; padding: 0px; border: 0px; font: inherit; vertical-align: baseline; box-sizing: inherit; -webkit-tap-highlight-color: transparent;\">Final inspection of in-house developed electronic technology, such as PCB and other electrical components.</div></li><li style=\"margin: 0px 0px 0px 16px; padding: 0px 0px 4px; border: 0px; font: inherit; vertical-align: baseline; box-sizing: inherit; -webkit-tap-highlight-color: transparent; list-style: outside disc;\"><div style=\"margin: 0px; padding: 0px; border: 0px; font: inherit; vertical-align: baseline; box-sizing: inherit; -webkit-tap-highlight-color: transparent;\">Maintain test equipment calibration utilizing internal and external resources.</div></li><li style=\"margin: 0px 0px 0px 16px; padding: 0px 0px 4px; border: 0px; font: inherit; vertical-align: baseline; box-sizing: inherit; -webkit-tap-highlight-color: transparent; list-style: outside disc;\"><div style=\"margin: 0px; padding: 0px; border: 0px; font: inherit; vertical-align: baseline; box-sizing: inherit; -webkit-tap-highlight-color: transparent;\">Conducting supplier audits and work with our supply chain to improve quality standards.</div></li><li style=\"margin: 0px 0px 0px 16px; padding: 0px 0px 4px; border: 0px; font: inherit; vertical-align: baseline; box-sizing: inherit; -webkit-tap-highlight-color: transparent; list-style: outside disc;\"><div style=\"margin: 0px; padding: 0px; border: 0px; font: inherit; vertical-align: baseline; box-sizing: inherit; -webkit-tap-highlight-color: transparent;\">Work with procurement team to achieve best cost/quality from our supply chain.</div></li><li style=\"margin: 0px 0px 0px 16px; padding: 0px 0px 4px; border: 0px; font: inherit; vertical-align: baseline; box-sizing: inherit; -webkit-tap-highlight-color: transparent; list-style: outside disc;\"><div style=\"margin: 0px; padding: 0px; border: 0px; font: inherit; vertical-align: baseline; box-sizing: inherit; -webkit-tap-highlight-color: transparent;\">Analyze quality data and turn unsatisfactory quality related trends into improvement actions.</div></li><li style=\"margin: 0px 0px 0px 16px; padding: 0px 0px 4px; border: 0px; font: inherit; vertical-align: baseline; box-sizing: inherit; -webkit-tap-highlight-color: transparent; list-style: outside disc;\"><div style=\"margin: 0px; padding: 0px; border: 0px; font: inherit; vertical-align: baseline; box-sizing: inherit; -webkit-tap-highlight-color: transparent;\">Work with our document controller to ensure all quality data is accurate and securely stored</div></li><li style=\"margin: 0px 0px 0px 16px; padding: 0px 0px 4px; border: 0px; font: inherit; vertical-align: baseline; box-sizing: inherit; -webkit-tap-highlight-color: transparent; list-style: outside disc;\"><div style=\"margin: 0px; padding: 0px; border: 0px; font: inherit; vertical-align: baseline; box-sizing: inherit; -webkit-tap-highlight-color: transparent;\">Work with our engineering, mechanical, electrical and electronics teams to ensure quality of products is continually improved.</div></li><li style=\"margin: 0px 0px 0px 16px; padding: 0px 0px 4px; border: 0px; font: inherit; vertical-align: baseline; box-sizing: inherit; -webkit-tap-highlight-color: transparent; list-style: outside disc;\"><div style=\"margin: 0px; padding: 0px; border: 0px; font: inherit; vertical-align: baseline; box-sizing: inherit; -webkit-tap-highlight-color: transparent;\">Improve test procedures to include the latest testing technology and automation</div></li><li style=\"margin: 0px 0px 0px 16px; padding: 0px 0px 4px; border: 0px; font: inherit; vertical-align: baseline; box-sizing: inherit; -webkit-tap-highlight-color: transparent; list-style: outside disc;\"><div style=\"margin: 0px; padding: 0px; border: 0px; font: inherit; vertical-align: baseline; box-sizing: inherit; -webkit-tap-highlight-color: transparent;\">Analyze feedback from our user community support department and initiate quality improvements.</div></li><li style=\"margin: 0px 0px 0px 16px; padding: 0px 0px 4px; border: 0px; font: inherit; vertical-align: baseline; box-sizing: inherit; -webkit-tap-highlight-color: transparent; list-style: outside disc;\"><div style=\"margin: 0px; padding: 0px; border: 0px; font: inherit; vertical-align: baseline; box-sizing: inherit; -webkit-tap-highlight-color: transparent;\">Conduct Root Cause Analysis on internal process issues or NCRs to suppliers, implement and monitor corrective actions and record any concessions.</div></li><li style=\"margin: 0px 0px 0px 16px; padding: 0px 0px 4px; border: 0px; font: inherit; vertical-align: baseline; box-sizing: inherit; -webkit-tap-highlight-color: transparent; list-style: outside disc;\"><div style=\"margin: 0px; padding: 0px; border: 0px; font: inherit; vertical-align: baseline; box-sizing: inherit; -webkit-tap-highlight-color: transparent;\">To interface with Second Party auditors to maintain Company “Approved Supplier Status” on client Quality Management Systems.</div></li></ul><div style=\"margin: 0px; padding: 0px; border: 0px; font-variant-numeric: inherit; font-variant-east-asian: inherit; font-stretch: inherit; line-height: inherit; font-family: Muli, -apple-system, system-ui, &quot;Segoe UI&quot;, Roboto, &quot;Noto Sans&quot;, Ubuntu, &quot;Droid Sans&quot;, &quot;Helvetica Neue&quot;, Arial, sans-serif; vertical-align: baseline; box-sizing: inherit; -webkit-tap-highlight-color: transparent; color: rgb(51, 51, 51); text-align: justify;\"><span style=\"margin: 0px; padding: 0px; border: 0px; font-style: inherit; font-variant: inherit; font-weight: 700; font-stretch: inherit; font-size: inherit; line-height: inherit; font-family: inherit; vertical-align: baseline; box-sizing: inherit; -webkit-tap-highlight-color: transparent;\">Key Requirements</span></div><ul style=\"margin-right: 0px; margin-bottom: 0px; margin-left: 0px; padding: 0px 0px 12px; border: 0px; font-variant-numeric: inherit; font-variant-east-asian: inherit; font-stretch: inherit; line-height: inherit; font-family: Muli, -apple-system, system-ui, &quot;Segoe UI&quot;, Roboto, &quot;Noto Sans&quot;, Ubuntu, &quot;Droid Sans&quot;, &quot;Helvetica Neue&quot;, Arial, sans-serif; vertical-align: baseline; list-style: none; box-sizing: inherit; -webkit-tap-highlight-color: transparent; color: rgb(51, 51, 51); text-align: justify;\"><li style=\"margin: 0px 0px 0px 16px; padding: 0px 0px 4px; border: 0px; font: inherit; vertical-align: baseline; box-sizing: inherit; -webkit-tap-highlight-color: transparent; list-style: outside disc;\"><div style=\"margin: 0px; padding: 0px; border: 0px; font: inherit; vertical-align: baseline; box-sizing: inherit; -webkit-tap-highlight-color: transparent;\">Showcase Fugro foundations</div><ul style=\"margin-right: 0px; margin-left: 0px; padding: 0px 0px 12px; border: 0px; font: inherit; vertical-align: baseline; list-style: none; box-sizing: inherit; -webkit-tap-highlight-color: transparent;\"><li style=\"margin: 0px 0px 0px 16px; padding: 0px 0px 4px; border: 0px; font: inherit; vertical-align: baseline; box-sizing: inherit; -webkit-tap-highlight-color: transparent; list-style: inside circle;\"><div style=\"margin: 0px; padding: 0px; border: 0px; font: inherit; vertical-align: baseline; box-sizing: inherit; -webkit-tap-highlight-color: transparent;\">Good citizenship</div></li><li style=\"margin: 0px 0px 0px 16px; padding: 0px 0px 4px; border: 0px; font: inherit; vertical-align: baseline; box-sizing: inherit; -webkit-tap-highlight-color: transparent; list-style: inside circle;\"><div style=\"margin: 0px; padding: 0px; border: 0px; font: inherit; vertical-align: baseline; box-sizing: inherit; -webkit-tap-highlight-color: transparent;\">Safety Leadership</div></li><li style=\"margin: 0px 0px 0px 16px; padding: 0px 0px 4px; border: 0px; font: inherit; vertical-align: baseline; box-sizing: inherit; -webkit-tap-highlight-color: transparent; list-style: inside circle;\"><div style=\"margin: 0px; padding: 0px; border: 0px; font: inherit; vertical-align: baseline; box-sizing: inherit; -webkit-tap-highlight-color: transparent;\">Client Focus</div></li><li style=\"margin: 0px 0px 0px 16px; padding: 0px 0px 4px; border: 0px; font: inherit; vertical-align: baseline; box-sizing: inherit; -webkit-tap-highlight-color: transparent; list-style: inside circle;\"><div style=\"margin: 0px; padding: 0px; border: 0px; font: inherit; vertical-align: baseline; box-sizing: inherit; -webkit-tap-highlight-color: transparent;\">Teamwork &amp; Communication</div></li></ul></li><li style=\"margin: 0px 0px 0px 16px; padding: 0px 0px 4px; border: 0px; font: inherit; vertical-align: baseline; box-sizing: inherit; -webkit-tap-highlight-color: transparent; list-style: outside disc;\"><div style=\"margin: 0px; padding: 0px; border: 0px; font: inherit; vertical-align: baseline; box-sizing: inherit; -webkit-tap-highlight-color: transparent;\">Relevant product and process quality qualifications is a pre.</div></li><li style=\"margin: 0px 0px 0px 16px; padding: 0px 0px 4px; border: 0px; font: inherit; vertical-align: baseline; box-sizing: inherit; -webkit-tap-highlight-color: transparent; list-style: outside disc;\"><div style=\"margin: 0px; padding: 0px; border: 0px; font: inherit; vertical-align: baseline; box-sizing: inherit; -webkit-tap-highlight-color: transparent;\">Minimum Diploma or Degree in technical or engineering subject, preferably electronics or mechatronics engineering.</div></li><li style=\"margin: 0px 0px 0px 16px; padding: 0px 0px 4px; border: 0px; font: inherit; vertical-align: baseline; box-sizing: inherit; -webkit-tap-highlight-color: transparent; list-style: outside disc;\"><div style=\"margin: 0px; padding: 0px; border: 0px; font: inherit; vertical-align: baseline; box-sizing: inherit; -webkit-tap-highlight-color: transparent;\">Aptitude and enthusiasm to develop knowledge and acquire new skills.</div></li><li style=\"margin: 0px 0px 0px 16px; padding: 0px 0px 4px; border: 0px; font: inherit; vertical-align: baseline; box-sizing: inherit; -webkit-tap-highlight-color: transparent; list-style: outside disc;\"><div style=\"margin: 0px; padding: 0px; border: 0px; font: inherit; vertical-align: baseline; box-sizing: inherit; -webkit-tap-highlight-color: transparent;\">Preferred experience in quality related field including knowledge of BS EN ISO 9001 Quality Management Systems.</div></li><li style=\"margin: 0px 0px 0px 16px; padding: 0px 0px 4px; border: 0px; font: inherit; vertical-align: baseline; box-sizing: inherit; -webkit-tap-highlight-color: transparent; list-style: outside disc;\"><div style=\"margin: 0px; padding: 0px; border: 0px; font: inherit; vertical-align: baseline; box-sizing: inherit; -webkit-tap-highlight-color: transparent;\">Ability to analyze quality data, identify trends and create improvement plans.</div></li><li style=\"margin: 0px 0px 0px 16px; padding: 0px 0px 4px; border: 0px; font: inherit; vertical-align: baseline; box-sizing: inherit; -webkit-tap-highlight-color: transparent; list-style: outside disc;\"><div style=\"margin: 0px; padding: 0px; border: 0px; font: inherit; vertical-align: baseline; box-sizing: inherit; -webkit-tap-highlight-color: transparent;\">Ability to work remotely with oversees teams and clients</div></li><li style=\"margin: 0px 0px 0px 16px; padding: 0px 0px 4px; border: 0px; font: inherit; vertical-align: baseline; box-sizing: inherit; -webkit-tap-highlight-color: transparent; list-style: outside disc;\"><div style=\"margin: 0px; padding: 0px; border: 0px; font: inherit; vertical-align: baseline; box-sizing: inherit; -webkit-tap-highlight-color: transparent;\">Ability to represent Fugro’s interest when meeting suppliers?</div></li><li style=\"margin: 0px 0px 0px 16px; padding: 0px 0px 4px; border: 0px; font: inherit; vertical-align: baseline; box-sizing: inherit; -webkit-tap-highlight-color: transparent; list-style: outside disc;\"><div style=\"margin: 0px; padding: 0px; border: 0px; font: inherit; vertical-align: baseline; box-sizing: inherit; -webkit-tap-highlight-color: transparent;\">Report directly to global ROV production manager to ensure quality is independently assessed.</div></li><li style=\"margin: 0px 0px 0px 16px; padding: 0px 0px 4px; border: 0px; font: inherit; vertical-align: baseline; box-sizing: inherit; -webkit-tap-highlight-color: transparent; list-style: outside disc;\"><div style=\"margin: 0px; padding: 0px; border: 0px; font: inherit; vertical-align: baseline; box-sizing: inherit; -webkit-tap-highlight-color: transparent;\">Willingness to work flexibly until tasks are finished if required.</div></li></ul><div style=\"margin: 0px; padding: 0px; border: 0px; font-variant-numeric: inherit; font-variant-east-asian: inherit; font-stretch: inherit; line-height: inherit; font-family: Muli, -apple-system, system-ui, &quot;Segoe UI&quot;, Roboto, &quot;Noto Sans&quot;, Ubuntu, &quot;Droid Sans&quot;, &quot;Helvetica Neue&quot;, Arial, sans-serif; vertical-align: baseline; box-sizing: inherit; -webkit-tap-highlight-color: transparent; color: rgb(51, 51, 51); text-align: justify;\"><span style=\"margin: 0px; padding: 0px; border: 0px; font-style: inherit; font-variant: inherit; font-weight: 700; font-stretch: inherit; font-size: inherit; line-height: inherit; font-family: inherit; vertical-align: baseline; box-sizing: inherit; -webkit-tap-highlight-color: transparent;\">We offer</span></div><div style=\"margin: 0px; padding: 0px; border: 0px; font-variant-numeric: inherit; font-variant-east-asian: inherit; font-stretch: inherit; line-height: inherit; font-family: Muli, -apple-system, system-ui, &quot;Segoe UI&quot;, Roboto, &quot;Noto Sans&quot;, Ubuntu, &quot;Droid Sans&quot;, &quot;Helvetica Neue&quot;, Arial, sans-serif; vertical-align: baseline; box-sizing: inherit; -webkit-tap-highlight-color: transparent; color: rgb(51, 51, 51); text-align: justify;\">A career at Fugro means challenging work in an international environment. You work in motivated teams with colleagues from all over the world. As a market leader in geo-information, At Fugro, you are part of state-of-the-art subsea technology, software development and engineering for our clients. Fugro is an international company with a wide range of global career potential. Professional personal development is available from external training course providers and Fugro Academy which offers courses for over 10.000 employees.</div><ul style=\"margin-right: 0px; margin-bottom: 0px; margin-left: 0px; padding: 0px 0px 12px; border: 0px; font-variant-numeric: inherit; font-variant-east-asian: inherit; font-stretch: inherit; line-height: inherit; font-family: Muli, -apple-system, system-ui, &quot;Segoe UI&quot;, Roboto, &quot;Noto Sans&quot;, Ubuntu, &quot;Droid Sans&quot;, &quot;Helvetica Neue&quot;, Arial, sans-serif; vertical-align: baseline; list-style: none; box-sizing: inherit; -webkit-tap-highlight-color: transparent; color: rgb(51, 51, 51); text-align: justify;\"><li style=\"margin: 0px 0px 0px 16px; padding: 0px 0px 4px; border: 0px; font: inherit; vertical-align: baseline; box-sizing: inherit; -webkit-tap-highlight-color: transparent; list-style: outside disc;\"><div style=\"margin: 0px; padding: 0px; border: 0px; font: inherit; vertical-align: baseline; box-sizing: inherit; -webkit-tap-highlight-color: transparent;\">The possibility to develop though training courses, working on-site and offshore.</div></li><li style=\"margin: 0px 0px 0px 16px; padding: 0px 0px 4px; border: 0px; font: inherit; vertical-align: baseline; box-sizing: inherit; -webkit-tap-highlight-color: transparent; list-style: outside disc;\"><div style=\"margin: 0px; padding: 0px; border: 0px; font: inherit; vertical-align: baseline; box-sizing: inherit; -webkit-tap-highlight-color: transparent;\">Work with industry leading subsea technology.</div></li><li style=\"margin: 0px 0px 0px 16px; padding: 0px 0px 4px; border: 0px; font: inherit; vertical-align: baseline; box-sizing: inherit; -webkit-tap-highlight-color: transparent; list-style: outside disc;\"><div style=\"margin: 0px; padding: 0px; border: 0px; font: inherit; vertical-align: baseline; box-sizing: inherit; -webkit-tap-highlight-color: transparent;\">A dynamic team with flat and informal working culture.</div></li><li style=\"margin: 0px 0px 0px 16px; padding: 0px 0px 4px; border: 0px; font: inherit; vertical-align: baseline; box-sizing: inherit; -webkit-tap-highlight-color: transparent; list-style: outside disc;\"><div style=\"margin: 0px; padding: 0px; border: 0px; font: inherit; vertical-align: baseline; box-sizing: inherit; -webkit-tap-highlight-color: transparent;\">Work directly with the production center manager to improve the quality of deliverables for a worldwide client base.</div></li></ul>', 'Junior', 'Higher Secondary/Pre-U/\'A\' Level, Diploma, Advanced/Higher/Graduate Diploma, Bachelor\'s Degree, Post Graduate Diploma, Professional Degree', 'Full-time', 'US', 2000, 3000, 1, 3, 1, '2019-12-09 01:10:00', '2019-12-09 01:10:00', NULL),
(2, 'Web Developer (Senior)', '2019-12-09 14:17:00', '<p>testing&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</p>', '<p>testing</p>', 'Senior', 'B.C.Sc or B.C.St', 'Full-time', 'US', 3000, 4000, 1, 2, 1, '2019-12-09 01:17:44', '2019-12-09 01:17:44', NULL),
(4, 'testing', '2019-12-18 05:25:00', '<p>testing&nbsp;&nbsp;&nbsp;&nbsp;</p>', '<p>testing</p>', 'Junior', 'B.C.Sc', 'Full-time', 'SGD', 3000, 4000, 1, 2, 2, '2019-12-09 22:26:16', '2019-12-10 00:33:34', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `job_specifications`
--

CREATE TABLE `job_specifications` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `link` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `job_specifications`
--

INSERT INTO `job_specifications` (`id`, `name`, `link`, `created_at`, `updated_at`, `deleted_at`) VALUES
(1, 'Job', 'Job.com', '2019-11-23 05:24:06', '2019-11-25 04:12:27', NULL),
(2, 'Facebook', 'facebook.com', '2019-11-23 05:24:16', '2019-11-23 05:24:16', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `job_types`
--

CREATE TABLE `job_types` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `job_types`
--

INSERT INTO `job_types` (`id`, `name`, `created_at`, `updated_at`, `deleted_at`) VALUES
(2, 'Web Developer', '2019-11-23 05:17:43', '2019-11-25 04:15:58', NULL),
(3, 'NodeJS Developer', '2019-11-23 05:17:57', '2019-11-23 05:17:57', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `migrations`
--

CREATE TABLE `migrations` (
  `id` int(10) UNSIGNED NOT NULL,
  `migration` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(1, '2014_10_12_000000_create_users_table', 1),
(2, '2014_10_12_100000_create_password_resets_table', 1),
(3, '2019_11_19_085440_create_job_types_table', 1),
(4, '2019_11_19_085941_create_nationalities_table', 1),
(5, '2019_11_19_090043_create_races_table', 1),
(6, '2019_11_19_090222_create_townships_table', 1),
(7, '2019_11_19_090315_create_streets_table', 1),
(8, '2019_11_19_090415_create_types_table', 1),
(9, '2019_11_19_090509_create_job_specifications_table', 1),
(10, '2019_11_19_090602_create_addresses_table', 1),
(11, '2019_11_19_090935_create_companies_table', 1),
(12, '2019_11_19_091636_create_jobs_table', 1),
(13, '2019_11_19_093030_create_save_jobs_table', 1),
(14, '2019_11_19_093315_create_user_detail_infos_table', 1),
(15, '2019_11_19_095019_add_active_to_users_table', 1),
(16, '2019_11_19_095255_add_softdelete_to_users_table', 1),
(17, '2019_11_29_080427_add_ea_register_no_to_companies_table', 2);

-- --------------------------------------------------------

--
-- Table structure for table `nationalities`
--

CREATE TABLE `nationalities` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `nationalities`
--

INSERT INTO `nationalities` (`id`, `name`, `created_at`, `updated_at`, `deleted_at`) VALUES
(1, 'Burmese', '2019-11-25 03:21:34', '2019-11-25 03:24:56', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `password_resets`
--

CREATE TABLE `password_resets` (
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `races`
--

CREATE TABLE `races` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `races`
--

INSERT INTO `races` (`id`, `name`, `deleted_at`, `created_at`, `updated_at`) VALUES
(1, 'Buddha', NULL, '2019-11-25 03:31:25', '2019-11-25 03:35:05');

-- --------------------------------------------------------

--
-- Table structure for table `save_jobs`
--

CREATE TABLE `save_jobs` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `job_id` bigint(20) UNSIGNED NOT NULL,
  `user_id` bigint(20) UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `streets`
--

CREATE TABLE `streets` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `streets`
--

INSERT INTO `streets` (`id`, `name`, `created_at`, `updated_at`, `deleted_at`) VALUES
(1, 'thamine saybutar(1)street, 946(3) floor', '2019-11-25 01:09:34', '2019-11-25 02:42:45', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `townships`
--

CREATE TABLE `townships` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `townships`
--

INSERT INTO `townships` (`id`, `name`, `created_at`, `updated_at`, `deleted_at`) VALUES
(1, 'Thamine', '2019-11-25 02:28:45', '2019-11-25 02:51:41', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `types`
--

CREATE TABLE `types` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `types`
--

INSERT INTO `types` (`id`, `name`, `created_at`, `updated_at`, `deleted_at`) VALUES
(1, 'Client Type1', '2019-11-23 05:25:20', '2019-11-25 03:52:20', NULL),
(2, 'Type2', '2019-11-23 05:25:25', '2019-11-23 05:25:25', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `active` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `email_verified_at`, `password`, `remember_token`, `created_at`, `updated_at`, `active`, `deleted_at`) VALUES
(1, 'Admin', 'admin@gmail.com', NULL, '$2y$10$qAuOiBVtuS7.dgu6V5LBEeOi9wIsjCbrqN0Xhz1dprDJJ4WaJEP1K', NULL, '2019-11-23 03:06:10', '2019-11-23 03:06:10', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `user_detail_infos`
--

CREATE TABLE `user_detail_infos` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `current_resident` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `permanent_resident` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `monthly_salary` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `prefer_specialization` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `prefer_worklocation` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `working_since` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `institute_university` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `insuni_location` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `qualification` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `field_of_study` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `graduation_date` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `position_title` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `company_name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `job_duration_from` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `job_duration_to` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `specialization` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `role` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `industry` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `position_level` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `phone_no` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_id` bigint(20) UNSIGNED NOT NULL,
  `nationality_id` bigint(20) UNSIGNED NOT NULL,
  `type_id` bigint(20) UNSIGNED NOT NULL,
  `address_id` bigint(20) UNSIGNED NOT NULL,
  `race_id` bigint(20) UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `addresses`
--
ALTER TABLE `addresses`
  ADD PRIMARY KEY (`id`),
  ADD KEY `addresses_township_id_foreign` (`township_id`),
  ADD KEY `addresses_street_id_foreign` (`street_id`);

--
-- Indexes for table `companies`
--
ALTER TABLE `companies`
  ADD PRIMARY KEY (`id`),
  ADD KEY `companies_type_id_foreign` (`type_id`);

--
-- Indexes for table `jobs`
--
ALTER TABLE `jobs`
  ADD PRIMARY KEY (`id`),
  ADD KEY `jobs_job_specification_id_foreign` (`job_specification_id`),
  ADD KEY `jobs_job_type_id_foreign` (`job_type_id`),
  ADD KEY `jobs_company_id_foreign` (`company_id`);

--
-- Indexes for table `job_specifications`
--
ALTER TABLE `job_specifications`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `job_types`
--
ALTER TABLE `job_types`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `migrations`
--
ALTER TABLE `migrations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `nationalities`
--
ALTER TABLE `nationalities`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `password_resets`
--
ALTER TABLE `password_resets`
  ADD KEY `password_resets_email_index` (`email`);

--
-- Indexes for table `races`
--
ALTER TABLE `races`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `save_jobs`
--
ALTER TABLE `save_jobs`
  ADD PRIMARY KEY (`id`),
  ADD KEY `save_jobs_job_id_foreign` (`job_id`),
  ADD KEY `save_jobs_user_id_foreign` (`user_id`);

--
-- Indexes for table `streets`
--
ALTER TABLE `streets`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `townships`
--
ALTER TABLE `townships`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `types`
--
ALTER TABLE `types`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `users_email_unique` (`email`);

--
-- Indexes for table `user_detail_infos`
--
ALTER TABLE `user_detail_infos`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_detail_infos_user_id_foreign` (`user_id`),
  ADD KEY `user_detail_infos_nationality_id_foreign` (`nationality_id`),
  ADD KEY `user_detail_infos_type_id_foreign` (`type_id`),
  ADD KEY `user_detail_infos_address_id_foreign` (`address_id`),
  ADD KEY `user_detail_infos_race_id_foreign` (`race_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `addresses`
--
ALTER TABLE `addresses`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `companies`
--
ALTER TABLE `companies`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `jobs`
--
ALTER TABLE `jobs`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `job_specifications`
--
ALTER TABLE `job_specifications`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `job_types`
--
ALTER TABLE `job_types`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `migrations`
--
ALTER TABLE `migrations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;

--
-- AUTO_INCREMENT for table `nationalities`
--
ALTER TABLE `nationalities`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `races`
--
ALTER TABLE `races`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `save_jobs`
--
ALTER TABLE `save_jobs`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `streets`
--
ALTER TABLE `streets`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `townships`
--
ALTER TABLE `townships`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `types`
--
ALTER TABLE `types`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `user_detail_infos`
--
ALTER TABLE `user_detail_infos`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `addresses`
--
ALTER TABLE `addresses`
  ADD CONSTRAINT `addresses_street_id_foreign` FOREIGN KEY (`street_id`) REFERENCES `streets` (`id`),
  ADD CONSTRAINT `addresses_township_id_foreign` FOREIGN KEY (`township_id`) REFERENCES `townships` (`id`);

--
-- Constraints for table `companies`
--
ALTER TABLE `companies`
  ADD CONSTRAINT `companies_type_id_foreign` FOREIGN KEY (`type_id`) REFERENCES `types` (`id`);

--
-- Constraints for table `jobs`
--
ALTER TABLE `jobs`
  ADD CONSTRAINT `jobs_company_id_foreign` FOREIGN KEY (`company_id`) REFERENCES `companies` (`id`),
  ADD CONSTRAINT `jobs_job_specification_id_foreign` FOREIGN KEY (`job_specification_id`) REFERENCES `job_specifications` (`id`),
  ADD CONSTRAINT `jobs_job_type_id_foreign` FOREIGN KEY (`job_type_id`) REFERENCES `job_types` (`id`);

--
-- Constraints for table `save_jobs`
--
ALTER TABLE `save_jobs`
  ADD CONSTRAINT `save_jobs_job_id_foreign` FOREIGN KEY (`job_id`) REFERENCES `jobs` (`id`),
  ADD CONSTRAINT `save_jobs_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`);

--
-- Constraints for table `user_detail_infos`
--
ALTER TABLE `user_detail_infos`
  ADD CONSTRAINT `user_detail_infos_address_id_foreign` FOREIGN KEY (`address_id`) REFERENCES `addresses` (`id`),
  ADD CONSTRAINT `user_detail_infos_nationality_id_foreign` FOREIGN KEY (`nationality_id`) REFERENCES `nationalities` (`id`),
  ADD CONSTRAINT `user_detail_infos_race_id_foreign` FOREIGN KEY (`race_id`) REFERENCES `races` (`id`),
  ADD CONSTRAINT `user_detail_infos_type_id_foreign` FOREIGN KEY (`type_id`) REFERENCES `types` (`id`),
  ADD CONSTRAINT `user_detail_infos_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
