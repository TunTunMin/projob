-- phpMyAdmin SQL Dump
-- version 4.9.0.1
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: Jan 12, 2020 at 07:46 AM
-- Server version: 10.3.16-MariaDB
-- PHP Version: 7.1.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `projob`
--

-- --------------------------------------------------------

--
-- Table structure for table `addresses`
--

CREATE TABLE `addresses` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `township_id` bigint(20) UNSIGNED NOT NULL,
  `street_id` bigint(20) UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `addresses`
--

INSERT INTO `addresses` (`id`, `township_id`, `street_id`, `created_at`, `updated_at`, `deleted_at`) VALUES
(1, 4, 1, '2020-01-11 23:41:47', '2020-01-11 23:42:00', NULL),
(2, 3, 1, '2020-01-11 23:41:54', '2020-01-11 23:41:54', NULL),
(3, 4, 3, '2020-01-11 23:42:08', '2020-01-11 23:42:08', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `companies`
--

CREATE TABLE `companies` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `company_overview` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `register_no` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `ea_no` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `company_size` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `industry` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `location` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `average_processtime` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `benefit_other` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `gallery` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `cover_photo` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `logo` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `type_id` bigint(20) UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `ea_register_no` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `website` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `facebook` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `field_studies`
--

CREATE TABLE `field_studies` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `field_studies`
--

INSERT INTO `field_studies` (`id`, `name`, `created_at`, `updated_at`, `deleted_at`) VALUES
(1, 'Advertising/Media', '2020-01-10 03:07:59', '2020-01-10 03:07:59', NULL),
(2, 'Agriculture/Aquaculture/Forestry', '2020-01-10 03:08:14', '2020-01-10 03:08:14', NULL),
(3, 'Airline Operation/Airport Management', '2020-01-10 03:08:21', '2020-01-10 03:08:21', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `industries`
--

CREATE TABLE `industries` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `industries`
--

INSERT INTO `industries` (`id`, `name`, `created_at`, `updated_at`, `deleted_at`) VALUES
(1, 'Accounting / Audit / Tax Services', '2020-01-09 17:30:00', '2020-01-09 17:30:00', NULL),
(2, 'Advertising / Marketing / Promotion / PR', '2020-01-09 17:30:00', '2020-01-09 17:30:00', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `jobs`
--

CREATE TABLE `jobs` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `title` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `post_date` datetime NOT NULL,
  `job_highlights` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `job_description` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `career_level` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `qualification` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `employee_type` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `salary_unit` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `salary_from` int(11) NOT NULL,
  `salary_to` int(11) NOT NULL,
  `job_specification_id` bigint(20) UNSIGNED NOT NULL,
  `job_type_id` bigint(20) UNSIGNED NOT NULL,
  `company_id` bigint(20) UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `job_specifications`
--

CREATE TABLE `job_specifications` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `link` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `job_types`
--

CREATE TABLE `job_types` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `job_types`
--

INSERT INTO `job_types` (`id`, `name`, `created_at`, `updated_at`, `deleted_at`) VALUES
(1, 'IT', '2020-01-12 00:01:24', '2020-01-12 00:01:24', NULL),
(2, 'Travel and Tours', '2020-01-12 00:01:41', '2020-01-12 00:01:41', NULL),
(3, 'Restaurant', '2020-01-12 00:02:16', '2020-01-12 00:02:16', NULL),
(4, 'Online Shopping', '2020-01-12 00:02:33', '2020-01-12 00:02:33', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `migrations`
--

CREATE TABLE `migrations` (
  `id` int(10) UNSIGNED NOT NULL,
  `migration` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(1, '2014_10_12_000000_create_users_table', 1),
(2, '2014_10_12_100000_create_password_resets_table', 1),
(3, '2019_11_19_085440_create_job_types_table', 1),
(4, '2019_11_19_085941_create_nationalities_table', 1),
(5, '2019_11_19_090043_create_races_table', 1),
(6, '2019_11_19_090222_create_townships_table', 1),
(7, '2019_11_19_090315_create_streets_table', 1),
(8, '2019_11_19_090415_create_types_table', 1),
(9, '2019_11_19_090509_create_job_specifications_table', 1),
(10, '2019_11_19_090602_create_addresses_table', 1),
(11, '2019_11_19_090935_create_companies_table', 1),
(12, '2019_11_19_091636_create_jobs_table', 1),
(13, '2019_11_19_093030_create_save_jobs_table', 1),
(14, '2019_11_19_093031_create_field_studies_table', 1),
(15, '2019_11_19_093032_create_qualifications_table', 1),
(16, '2019_11_19_093035_create_prefer_specializations_table', 1),
(17, '2019_11_19_093315_create_user_detail_infos_table', 1),
(18, '2019_11_19_095019_add_active_to_users_table', 1),
(19, '2019_11_19_095255_add_softdelete_to_users_table', 1),
(20, '2019_11_29_080427_add_ea_register_no_to_companies_table', 1),
(21, '2019_12_30_090536_add_votes_to_companies_table', 1),
(22, '2020_01_10_034624_create_roles_table', 1),
(23, '2020_01_10_075012_create_industries_table', 1),
(24, '2020_01_10_075014_add_changenameindustry_to_user_detail_infos_table', 1),
(25, '2020_01_10_135321_add_role_id_to_roles', 2),
(26, '2020_01_10_135846_add_role_id_to_user_detail_infos', 3);

-- --------------------------------------------------------

--
-- Table structure for table `nationalities`
--

CREATE TABLE `nationalities` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `nationalities`
--

INSERT INTO `nationalities` (`id`, `name`, `created_at`, `updated_at`, `deleted_at`) VALUES
(1, 'Myanmar', '2020-01-09 17:30:00', '2020-01-09 17:30:00', NULL),
(2, 'English', '2020-01-09 17:30:00', '2020-01-09 17:30:00', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `password_resets`
--

CREATE TABLE `password_resets` (
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `prefer_specializations`
--

CREATE TABLE `prefer_specializations` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `prefer_specializations`
--

INSERT INTO `prefer_specializations` (`id`, `name`, `created_at`, `updated_at`, `deleted_at`) VALUES
(1, 'Banking/Financial', '2020-01-10 03:08:47', '2020-01-10 03:08:47', NULL),
(2, 'Corporate Finance/Investment', '2020-01-10 03:08:57', '2020-01-10 03:08:57', NULL),
(3, 'General/Cost Accounting', '2020-01-10 03:09:07', '2020-01-10 03:09:07', NULL),
(4, 'Computer IT software', '2020-01-10 06:13:43', '2020-01-10 06:13:43', NULL),
(5, 'Computer IT hardware', '2020-01-10 06:13:50', '2020-01-10 06:13:50', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `qualifications`
--

CREATE TABLE `qualifications` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `qualifications`
--

INSERT INTO `qualifications` (`id`, `name`, `created_at`, `updated_at`, `deleted_at`) VALUES
(1, 'Higher Secondary/Pre-U', '2020-01-10 06:11:02', '2020-01-10 06:11:02', NULL),
(2, 'Professional Certificate', '2020-01-10 06:11:15', '2020-01-10 06:11:15', NULL),
(3, 'Bachelor\'s Degree', '2020-01-10 06:13:02', '2020-01-10 06:13:02', NULL),
(4, 'Post Graduate Diploma', '2020-01-10 06:13:17', '2020-01-10 06:13:17', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `races`
--

CREATE TABLE `races` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `roles`
--

CREATE TABLE `roles` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `prefer_specializations_id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `roles`
--

INSERT INTO `roles` (`id`, `prefer_specializations_id`, `name`, `created_at`, `updated_at`, `deleted_at`) VALUES
(1, 4, 'Programmer', '2020-01-10 06:14:20', '2020-01-10 06:14:20', NULL),
(2, 4, 'Engineer', '2020-01-10 06:14:31', '2020-01-10 06:14:31', NULL),
(3, 4, 'Tester', '2020-01-10 06:14:41', '2020-01-10 06:14:41', NULL),
(4, 5, 'Network engineer', '2020-01-10 06:14:55', '2020-01-10 06:14:55', NULL),
(5, 5, 'Service staff', '2020-01-10 06:15:05', '2020-01-10 06:15:05', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `save_jobs`
--

CREATE TABLE `save_jobs` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `job_id` bigint(20) UNSIGNED NOT NULL,
  `user_id` bigint(20) UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `streets`
--

CREATE TABLE `streets` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `streets`
--

INSERT INTO `streets` (`id`, `name`, `created_at`, `updated_at`, `deleted_at`) VALUES
(1, '1str', '2020-01-11 23:41:24', '2020-01-11 23:41:24', NULL),
(2, '2 str', '2020-01-11 23:41:30', '2020-01-11 23:41:30', NULL),
(3, '3 str', '2020-01-11 23:41:36', '2020-01-11 23:41:36', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `townships`
--

CREATE TABLE `townships` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `townships`
--

INSERT INTO `townships` (`id`, `name`, `created_at`, `updated_at`, `deleted_at`) VALUES
(1, 'Anywhere in singapore', '2020-01-10 06:15:31', '2020-01-10 06:15:31', NULL),
(2, 'Anywhere in Yangon', '2020-01-10 06:15:39', '2020-01-10 06:15:39', NULL),
(3, 'Hlaing Township', '2020-01-10 06:15:50', '2020-01-10 06:15:50', NULL),
(4, 'Mayan Gone Township', '2020-01-10 06:16:01', '2020-01-10 06:16:01', NULL),
(5, 'Thar kay Ta', '2020-01-10 06:16:11', '2020-01-10 06:16:11', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `types`
--

CREATE TABLE `types` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `types`
--

INSERT INTO `types` (`id`, `name`, `created_at`, `updated_at`, `deleted_at`) VALUES
(1, 'Admin', '2020-01-09 17:30:00', '2020-01-09 17:30:00', NULL),
(2, 'Job Seeker', '2020-01-09 17:30:00', '2020-01-09 17:30:00', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `active` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0',
  `deleted_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `email_verified_at`, `password`, `remember_token`, `created_at`, `updated_at`, `active`, `deleted_at`) VALUES
(1, 'Admin', 'admin@gmail.com', NULL, '$2y$10$Nu9wqB2DfIEtMSJDx3fz1.NleecMPyEFoo1OO2q/zRCf7YI45aW5u', NULL, '2020-01-10 02:27:58', '2020-01-10 02:27:58', '0', NULL),
(2, 'Aung Htoo Win', 'aunghtoowin@gmail.com', NULL, '$2y$10$L1EoQp86Twb.5TgJBOGzseP0ESL4kxfsQNZkssLyaR/43LCe1ta2u', NULL, '2020-01-10 06:30:26', '2020-01-10 06:30:26', '0', NULL),
(3, 'Tester', 'testing@gmail.com', NULL, '$2y$10$DH/VcuPDzP/iP.4z2ExoYO8TUYnLCfUCkqPIZEYkwqTp5wtM3Doaq', NULL, '2020-01-10 07:38:57', '2020-01-10 07:38:57', '0', NULL),
(4, 'Kyaw Ye Aung', 'kya@gmail.com', NULL, '$2y$10$jE3jE4BdHvsAr884I8V8zOn4Yn2mP9JG3eS1NQBNdlj8mWZ0d6i2.', NULL, '2020-01-10 08:13:50', '2020-01-10 08:13:50', '0', NULL),
(5, 'Tun Min', 'tunmin@gmail.com', NULL, '$2y$10$wM1RIfXqHYdUhDIoElK0U.dj5msN5dfmfErvrau01FYvL9UbZUN7C', NULL, '2020-01-10 08:19:44', '2020-01-10 08:19:44', '0', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `user_detail_infos`
--

CREATE TABLE `user_detail_infos` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `current_resident` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `permanent_resident` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `monthly_salary` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `currency_unit` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `working_since` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `institute_university` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `graduation_date` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `position_title` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `company_name` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `job_duration_from` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `job_duration_to` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `specialization` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `position_level` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `phone_no` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `qualification_id` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `preferwork_location_id` bigint(20) UNSIGNED DEFAULT NULL,
  `prefer_specializations_id` bigint(20) UNSIGNED DEFAULT NULL,
  `field_studies_id` bigint(20) UNSIGNED DEFAULT NULL,
  `institute_locations_id` bigint(20) UNSIGNED DEFAULT NULL,
  `user_id` bigint(20) UNSIGNED DEFAULT NULL,
  `nationality_id` bigint(20) UNSIGNED DEFAULT NULL,
  `type_id` bigint(20) UNSIGNED DEFAULT NULL,
  `address_id` bigint(20) UNSIGNED DEFAULT NULL,
  `race_id` bigint(20) UNSIGNED DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `industries_id` bigint(20) UNSIGNED DEFAULT NULL,
  `role_id` bigint(20) UNSIGNED DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `user_detail_infos`
--

INSERT INTO `user_detail_infos` (`id`, `current_resident`, `permanent_resident`, `monthly_salary`, `currency_unit`, `working_since`, `institute_university`, `graduation_date`, `position_title`, `company_name`, `job_duration_from`, `job_duration_to`, `specialization`, `position_level`, `phone_no`, `qualification_id`, `preferwork_location_id`, `prefer_specializations_id`, `field_studies_id`, `institute_locations_id`, `user_id`, `nationality_id`, `type_id`, `address_id`, `race_id`, `created_at`, `updated_at`, `deleted_at`, `industries_id`, `role_id`) VALUES
(1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, NULL, '2020-01-10 02:27:58', '2020-01-10 02:27:58', NULL, NULL, NULL),
(2, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 2, NULL, 2, NULL, NULL, '2020-01-10 06:30:26', '2020-01-10 06:30:26', NULL, NULL, NULL),
(3, NULL, NULL, NULL, NULL, NULL, 'University of Computer Studies, Meiktila', '\"2018-02\"', 'Full-stack developer', 'HostMyanmar', '2017-08', '2019-06', NULL, '1', '09978159437', '[\"3\"]', NULL, NULL, 1, 1, 3, NULL, 2, NULL, NULL, '2020-01-10 07:38:57', '2020-01-10 08:07:16', NULL, 1, 1),
(4, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 4, NULL, 2, NULL, NULL, '2020-01-10 08:13:50', '2020-01-10 08:13:50', NULL, NULL, NULL),
(5, '1', NULL, NULL, '2800', '2017', 'University of Computer Studies, Meiktila', '\"2018-02\"', 'Full-stack devloper', 'Hostmyanmar', '2017-08', '2019-06', NULL, '1', '09978159437', '[\"3\"]', 1, 4, 2, 2, 5, 1, 2, NULL, NULL, '2020-01-10 08:19:44', '2020-01-10 08:22:01', NULL, 1, 1);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `addresses`
--
ALTER TABLE `addresses`
  ADD PRIMARY KEY (`id`),
  ADD KEY `addresses_township_id_foreign` (`township_id`),
  ADD KEY `addresses_street_id_foreign` (`street_id`);

--
-- Indexes for table `companies`
--
ALTER TABLE `companies`
  ADD PRIMARY KEY (`id`),
  ADD KEY `companies_type_id_foreign` (`type_id`);

--
-- Indexes for table `field_studies`
--
ALTER TABLE `field_studies`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `industries`
--
ALTER TABLE `industries`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `jobs`
--
ALTER TABLE `jobs`
  ADD PRIMARY KEY (`id`),
  ADD KEY `jobs_job_specification_id_foreign` (`job_specification_id`),
  ADD KEY `jobs_job_type_id_foreign` (`job_type_id`),
  ADD KEY `jobs_company_id_foreign` (`company_id`);

--
-- Indexes for table `job_specifications`
--
ALTER TABLE `job_specifications`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `job_types`
--
ALTER TABLE `job_types`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `migrations`
--
ALTER TABLE `migrations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `nationalities`
--
ALTER TABLE `nationalities`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `password_resets`
--
ALTER TABLE `password_resets`
  ADD KEY `password_resets_email_index` (`email`);

--
-- Indexes for table `prefer_specializations`
--
ALTER TABLE `prefer_specializations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `qualifications`
--
ALTER TABLE `qualifications`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `races`
--
ALTER TABLE `races`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `roles`
--
ALTER TABLE `roles`
  ADD PRIMARY KEY (`id`),
  ADD KEY `roles_prefer_specializations_id_foreign` (`prefer_specializations_id`);

--
-- Indexes for table `save_jobs`
--
ALTER TABLE `save_jobs`
  ADD PRIMARY KEY (`id`),
  ADD KEY `save_jobs_job_id_foreign` (`job_id`),
  ADD KEY `save_jobs_user_id_foreign` (`user_id`);

--
-- Indexes for table `streets`
--
ALTER TABLE `streets`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `townships`
--
ALTER TABLE `townships`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `types`
--
ALTER TABLE `types`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `users_email_unique` (`email`);

--
-- Indexes for table `user_detail_infos`
--
ALTER TABLE `user_detail_infos`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_detail_infos_preferwork_location_id_foreign` (`preferwork_location_id`),
  ADD KEY `user_detail_infos_prefer_specializations_id_foreign` (`prefer_specializations_id`),
  ADD KEY `user_detail_infos_field_studies_id_foreign` (`field_studies_id`),
  ADD KEY `user_detail_infos_institute_locations_id_foreign` (`institute_locations_id`),
  ADD KEY `user_detail_infos_user_id_foreign` (`user_id`),
  ADD KEY `user_detail_infos_nationality_id_foreign` (`nationality_id`),
  ADD KEY `user_detail_infos_type_id_foreign` (`type_id`),
  ADD KEY `user_detail_infos_address_id_foreign` (`address_id`),
  ADD KEY `user_detail_infos_race_id_foreign` (`race_id`),
  ADD KEY `user_detail_infos_industries_id_foreign` (`industries_id`),
  ADD KEY `user_detail_infos_role_id_foreign` (`role_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `addresses`
--
ALTER TABLE `addresses`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `companies`
--
ALTER TABLE `companies`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `field_studies`
--
ALTER TABLE `field_studies`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `industries`
--
ALTER TABLE `industries`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `jobs`
--
ALTER TABLE `jobs`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `job_specifications`
--
ALTER TABLE `job_specifications`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `job_types`
--
ALTER TABLE `job_types`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `migrations`
--
ALTER TABLE `migrations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=27;

--
-- AUTO_INCREMENT for table `nationalities`
--
ALTER TABLE `nationalities`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `prefer_specializations`
--
ALTER TABLE `prefer_specializations`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `qualifications`
--
ALTER TABLE `qualifications`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `races`
--
ALTER TABLE `races`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `roles`
--
ALTER TABLE `roles`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `save_jobs`
--
ALTER TABLE `save_jobs`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `streets`
--
ALTER TABLE `streets`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `townships`
--
ALTER TABLE `townships`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `types`
--
ALTER TABLE `types`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `user_detail_infos`
--
ALTER TABLE `user_detail_infos`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `addresses`
--
ALTER TABLE `addresses`
  ADD CONSTRAINT `addresses_street_id_foreign` FOREIGN KEY (`street_id`) REFERENCES `streets` (`id`),
  ADD CONSTRAINT `addresses_township_id_foreign` FOREIGN KEY (`township_id`) REFERENCES `townships` (`id`);

--
-- Constraints for table `companies`
--
ALTER TABLE `companies`
  ADD CONSTRAINT `companies_type_id_foreign` FOREIGN KEY (`type_id`) REFERENCES `types` (`id`);

--
-- Constraints for table `jobs`
--
ALTER TABLE `jobs`
  ADD CONSTRAINT `jobs_company_id_foreign` FOREIGN KEY (`company_id`) REFERENCES `companies` (`id`),
  ADD CONSTRAINT `jobs_job_specification_id_foreign` FOREIGN KEY (`job_specification_id`) REFERENCES `job_specifications` (`id`),
  ADD CONSTRAINT `jobs_job_type_id_foreign` FOREIGN KEY (`job_type_id`) REFERENCES `job_types` (`id`);

--
-- Constraints for table `roles`
--
ALTER TABLE `roles`
  ADD CONSTRAINT `roles_prefer_specializations_id_foreign` FOREIGN KEY (`prefer_specializations_id`) REFERENCES `prefer_specializations` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `save_jobs`
--
ALTER TABLE `save_jobs`
  ADD CONSTRAINT `save_jobs_job_id_foreign` FOREIGN KEY (`job_id`) REFERENCES `jobs` (`id`),
  ADD CONSTRAINT `save_jobs_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`);

--
-- Constraints for table `user_detail_infos`
--
ALTER TABLE `user_detail_infos`
  ADD CONSTRAINT `user_detail_infos_address_id_foreign` FOREIGN KEY (`address_id`) REFERENCES `addresses` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `user_detail_infos_field_studies_id_foreign` FOREIGN KEY (`field_studies_id`) REFERENCES `field_studies` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `user_detail_infos_industries_id_foreign` FOREIGN KEY (`industries_id`) REFERENCES `industries` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `user_detail_infos_institute_locations_id_foreign` FOREIGN KEY (`institute_locations_id`) REFERENCES `townships` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `user_detail_infos_nationality_id_foreign` FOREIGN KEY (`nationality_id`) REFERENCES `nationalities` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `user_detail_infos_prefer_specializations_id_foreign` FOREIGN KEY (`prefer_specializations_id`) REFERENCES `prefer_specializations` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `user_detail_infos_preferwork_location_id_foreign` FOREIGN KEY (`preferwork_location_id`) REFERENCES `townships` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `user_detail_infos_race_id_foreign` FOREIGN KEY (`race_id`) REFERENCES `races` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `user_detail_infos_role_id_foreign` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `user_detail_infos_type_id_foreign` FOREIGN KEY (`type_id`) REFERENCES `types` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `user_detail_infos_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
